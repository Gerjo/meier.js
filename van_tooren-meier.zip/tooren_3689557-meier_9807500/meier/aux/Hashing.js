define(function(require) {
    var self = {
        
        
    }; // end self
    
    return self;
});