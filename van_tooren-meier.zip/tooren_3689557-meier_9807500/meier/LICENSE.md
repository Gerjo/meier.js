Meier.js - a game and math prototype library.

Copyright 2013 (C) Gerard J. Meier <gerjoo@gmail.com>

